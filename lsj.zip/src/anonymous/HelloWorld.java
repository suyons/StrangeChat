package anonymous;

public class HelloWorld {

	public static void main(String[] args) {
		Person p1 = new Person("홍길동") {
			
		}
	}

}
